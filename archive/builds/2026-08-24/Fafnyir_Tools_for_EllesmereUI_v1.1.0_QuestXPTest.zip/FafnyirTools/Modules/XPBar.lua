local ADDON_NAME, ns = ...

local feature = {
    key = "XPBar",
    page = "UI Tweaks",
    searchTerms = {
        "ui tweaks",
        "xp bar",
        "experience bar",
        "gradient",
        "rested xp",
        "quest xp",
        "data bar",
    },
}

ns:RegisterFeature(feature.key, feature)

local XP_BAR_NAME = "EllesmereEAB_XPBar_Bar"
local RESTED_BAR_NAME = "EllesmereEAB_XPBar_Rested"
local retryTicker
local hooksInstalled = false
local applying = false
local questXPBar

local function AtMaxLevel()
    if IsPlayerAtEffectiveMaxLevel and IsPlayerAtEffectiveMaxLevel() then return true end
    local level = UnitLevel("player") or 0
    if IsLevelAtEffectiveMaxLevel and IsLevelAtEffectiveMaxLevel(level) then return true end
    local maxLevel = (GetMaxLevelForPlayerExpansion and GetMaxLevelForPlayerExpansion())
        or (GetMaxPlayerLevel and GetMaxPlayerLevel())
    return (maxLevel and level >= maxLevel) or false
end

local function DB()
    return ns:GetDatabase().xpBar
end

local function GetColor(key, fallback)
    local settings = DB()
    local value = settings[key]

    if type(value) ~= "table" then
        value = {
            r = fallback.r,
            g = fallback.g,
            b = fallback.b,
            a = fallback.a,
        }
        settings[key] = value
    end

    return value
end

local function ApplyGradient(texture, orientation, first, second)
    if not texture then return end

    texture:SetVertexColor(1, 1, 1, 1)

    if texture.SetGradient and CreateColor then
        texture:SetGradient(
            orientation,
            CreateColor(first.r, first.g, first.b, first.a or 1),
            CreateColor(second.r, second.g, second.b, second.a or 1)
        )
    elseif texture.SetGradientAlpha then
        texture:SetGradientAlpha(
            orientation,
            first.r, first.g, first.b, first.a or 1,
            second.r, second.g, second.b, second.a or 1
        )
    end
end

local function GetCompletedQuestXP()
    if not (C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo
        and C_QuestLog.IsComplete and GetQuestLogRewardXP)
    then
        feature.questXPDebug = "required quest API unavailable"
        return 0
    end

    local total = 0
    local completedCount = 0
    for index = 1, C_QuestLog.GetNumQuestLogEntries() do
        local info = C_QuestLog.GetInfo(index)
        local questID = info and not info.isHeader and info.questID
        if questID and C_QuestLog.IsComplete and C_QuestLog.IsComplete(questID) then
            completedCount = completedCount + 1
            -- Current clients accept the quest ID even though Blizzard also
            -- calls this legacy global without one for the focused quest.
            local rewardXP = GetQuestLogRewardXP(questID) or 0
            if type(rewardXP) == "number" and rewardXP > 0 then
                total = total + rewardXP
            end
        end
    end
    feature.questXPDebug = string.format("completed=%d totalXP=%d", completedCount, total)
    return total
end

local function HideQuestXP()
    if questXPBar then questXPBar:Hide() end
end

function feature:UpdateQuestXP()
    local xpBar = _G[XP_BAR_NAME]
    local holder = xpBar and xpBar:GetParent()
    local settings = DB()
    if not holder or not settings.questXPEnabled or AtMaxLevel()
        or (IsXPUserDisabled and IsXPUserDisabled())
    then
        HideQuestXP()
        return
    end

    local currentXP = UnitXP("player") or 0
    local maxXP = UnitXPMax("player") or 0
    local questXP = GetCompletedQuestXP()
    local available = maxXP - currentXP
    if maxXP <= 0 or available <= 0 or questXP <= 0 then
        HideQuestXP()
        return
    end

    if not questXPBar then
        questXPBar = CreateFrame("StatusBar", nil, holder)
        questXPBar:SetAllPoints(xpBar)
        questXPBar:SetFrameLevel(xpBar:GetFrameLevel())
    end

    local segmentXP = math.min(questXP, available)
    local color = GetColor("questXPColor", ns.defaults.xpBar.questXPColor)
    local barTexture = xpBar:GetStatusBarTexture()

    questXPBar:SetStatusBarTexture(barTexture and barTexture:GetTexture()
        or "Interface\\BUTTONS\\WHITE8X8")
    questXPBar:GetStatusBarTexture():SetDrawLayer("ARTWORK", 3)
    questXPBar:SetOrientation(xpBar:GetOrientation())
    questXPBar:SetRotatesTexture(xpBar:GetOrientation() ~= "HORIZONTAL")
    questXPBar:SetMinMaxValues(0, maxXP)
    questXPBar:SetValue(currentXP + segmentXP)
    questXPBar:SetStatusBarColor(color.r, color.g, color.b, color.a or 1)
    questXPBar:Show()
end


function feature:Apply()
    if applying then return true end

    local xpBar = _G[XP_BAR_NAME]
    local restedBar = _G[RESTED_BAR_NAME]
    if not xpBar then return false end

    applying = true

    local settings = DB()
    local defaults = ns.defaults.xpBar
    local orientation = settings.orientation or "HORIZONTAL"
    local holder = xpBar:GetParent()

    if not settings.enabled then
        if holder and holder._updateFunc then
            holder._updateFunc()
        end

        self:UpdateQuestXP()
        applying = false
        return true
    end

    if restedBar and not settings.restedEnabled then
        if holder and holder._updateFunc then
            holder._updateFunc()
        end
    end

    ApplyGradient(
        xpBar:GetStatusBarTexture(),
        orientation,
        GetColor("startColor", defaults.startColor),
        GetColor("endColor", defaults.endColor)
    )

    if restedBar and settings.restedEnabled then
        ApplyGradient(
            restedBar:GetStatusBarTexture(),
            orientation,
            GetColor("restedStartColor", defaults.restedStartColor),
            GetColor("restedEndColor", defaults.restedEndColor)
        )
    end

    self:UpdateQuestXP()

    applying = false
    return true
end

function feature:Refresh()
    if not self:Apply() then
        self:StartRetry()
    end
end

function feature:StartRetry()
    if retryTicker then return end

    retryTicker = C_Timer.NewTicker(0.5, function()
        if feature:Apply() then
            retryTicker:Cancel()
            retryTicker = nil
            feature:InstallHooks()
        end
    end)
end

function feature:InstallHooks()
    if hooksInstalled then return true end

    local xpBar = _G[XP_BAR_NAME]
    local restedBar = _G[RESTED_BAR_NAME]
    if not xpBar then return false end

    hooksInstalled = true

    hooksecurefunc(xpBar, "SetStatusBarColor", function()
        if DB().enabled and not applying then
            feature:Apply()
        end
    end)

    if restedBar then
        hooksecurefunc(restedBar, "SetStatusBarColor", function()
            if DB().enabled and DB().restedEnabled and not applying then
                feature:Apply()
            end
        end)
    end

    return true
end

function feature:Initialize()
    if self:Apply() then
        self:InstallHooks()
    else
        self:StartRetry()
    end
end

function feature:Reset()
    local settings = DB()

    for key, value in pairs(ns.defaults.xpBar) do
        if type(value) == "table" then
            settings[key] = {
                r = value.r,
                g = value.g,
                b = value.b,
                a = value.a,
            }
        else
            settings[key] = value
        end
    end

    self:Refresh()
end

local function AttachSwatch(region, key, fallback)
    local swatch, refresh = EllesmereUI.BuildColorSwatch(
        region,
        region:GetFrameLevel() + 5,
        function()
            local color = GetColor(key, fallback)
            return color.r, color.g, color.b, color.a or 1
        end,
        function(r, g, b, a)
            local color = GetColor(key, fallback)
            color.r = r
            color.g = g
            color.b = b
            color.a = a or color.a or 1
            feature:Refresh()
        end,
        true,
        22
    )

    swatch:SetPoint("RIGHT", region, "RIGHT", -8, 0)
    region._lastInline = swatch

    if EllesmereUI.RegisterWidgetRefresh then
        EllesmereUI.RegisterWidgetRefresh(refresh)
    end
end

function feature:BuildOptions(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local h
    local defaults = ns.defaults.xpBar

    parent._showRowDivider = true

    _, h = W:SectionHeader(parent, "XP BAR GRADIENT", y)
    y = y - h

    _, h = W:DualRow(
        parent,
        y,
        {
            type = "toggle",
            text = "Enable XP Bar Gradient",
            getValue = function() return DB().enabled end,
            setValue = function(value)
                DB().enabled = value
                feature:Refresh()
            end,
        },
        {
            type = "dropdown",
            text = "Gradient Direction",
            values = {
                HORIZONTAL = "Horizontal",
                VERTICAL = "Vertical",
            },
            order = { "HORIZONTAL", "VERTICAL" },
            getValue = function()
                return DB().orientation or "HORIZONTAL"
            end,
            setValue = function(value)
                DB().orientation = value
                feature:Refresh()
            end,
        }
    )
    y = y - h

    local mainRow
    mainRow, h = W:DualRow(
        parent,
        y,
        { type = "label", text = "Gradient Start Color" },
        { type = "label", text = "Gradient End Color" }
    )
    y = y - h

    AttachSwatch(mainRow._leftRegion, "startColor", defaults.startColor)
    AttachSwatch(mainRow._rightRegion, "endColor", defaults.endColor)

    _, h = W:Spacer(parent, y, 18)
    y = y - h

    _, h = W:SectionHeader(parent, "RESTED XP GRADIENT", y)
    y = y - h

    _, h = W:DualRow(
        parent,
        y,
        {
            type = "toggle",
            text = "Enable Rested XP Gradient",
            getValue = function() return DB().restedEnabled end,
            setValue = function(value)
                DB().restedEnabled = value
                feature:Refresh()
            end,
        },
        {
            type = "button",
            text = "Reset XP Gradient",
            buttonText = "Reset",
            onClick = function()
                feature:Reset()
                if EllesmereUI and EllesmereUI.RefreshPage then
                    EllesmereUI:RefreshPage(true)
                end
            end,
        }
    )
    y = y - h

    local restedRow
    restedRow, h = W:DualRow(
        parent,
        y,
        { type = "label", text = "Rested Start Color" },
        { type = "label", text = "Rested End Color" }
    )
    y = y - h

    AttachSwatch(restedRow._leftRegion, "restedStartColor", defaults.restedStartColor)
    AttachSwatch(restedRow._rightRegion, "restedEndColor", defaults.restedEndColor)

    _, h = W:Spacer(parent, y, 18)
    y = y - h

    _, h = W:SectionHeader(parent, "QUEST XP", y)
    y = y - h

    local questRow
    questRow, h = W:DualRow(parent, y,
        {
            type = "toggle",
            text = "Show Completed Quest XP",
            getValue = function() return DB().questXPEnabled end,
            setValue = function(value)
                DB().questXPEnabled = value
                feature:Refresh()
            end,
        },
        { type = "label", text = "Quest XP Color" })
    y = y - h

    AttachSwatch(questRow._rightRegion, "questXPColor", defaults.questXPColor)

    return math.abs(y)
end

function feature:HandleEvent(event)
    if event == "PLAYER_ENTERING_WORLD"
        or event == "PLAYER_XP_UPDATE"
        or event == "PLAYER_LEVEL_UP"
        or event == "UPDATE_EXHAUSTION"
        or event == "QUEST_LOG_UPDATE"
        or event == "QUEST_ACCEPTED"
        or event == "QUEST_REMOVED"
        or event == "QUEST_TURNED_IN"
        or event == "QUEST_DATA_LOAD_RESULT"
    then
        C_Timer.After(0, function() feature:Refresh() end)
    end
end
