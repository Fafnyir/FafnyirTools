local ADDON_NAME, ns = ...

local feature = { key = "FlyoutButtonMatch" }
ns:RegisterFeature(feature.key, feature)

local hooked = false

local function IsEllesmereButton(button)
    local name = button and button:GetName()
    return name and name:match("^EABButton") ~= nil
end

local function MatchFlyoutButtons()
    local flyout = _G.SpellFlyout
    if not flyout or not flyout:IsShown() then return end

    local caller = flyout:GetParent()
    if not IsEllesmereButton(caller) then return end

    local width, height = caller:GetWidth(), caller:GetHeight()
    if not width or width <= 0 or not height or height <= 0 then return end

    for i = 1, flyout:GetNumChildren() do
        local child = select(i, flyout:GetChildren())
        if child and child:IsShown() and (child.icon or child.Icon) then
            -- SpellFlyout is parented to the calling EABButton and therefore
            -- already inherits its effective scale. Match only its local
            -- dimensions so custom-sized buttons do not remain native 45x45.
            pcall(child.SetScale, child, 1)
            pcall(child.SetSize, child, width, height)

            if child.cooldown and not child.cooldown:IsForbidden() then
                pcall(child.cooldown.SetAllPoints, child.cooldown, child)
            end
        end
    end
end

local function InstallHook()
    local flyout = _G.SpellFlyout
    if hooked or not flyout then return hooked end

    flyout:HookScript("OnShow", function()
        -- Ellesmere's own OnShow hook applies shape, border, and zoom first.
        -- Run once immediately and once after Blizzard finishes pool layout.
        MatchFlyoutButtons()
        C_Timer.After(0, MatchFlyoutButtons)
    end)

    hooked = true
    return true
end

function feature:Initialize()
    if InstallHook() then return end

    C_Timer.After(0.5, InstallHook)
    C_Timer.After(1, InstallHook)
    C_Timer.After(2, InstallHook)
end

function feature:HandleEvent(event)
    if event == "PLAYER_ENTERING_WORLD" then
        InstallHook()
    elseif event == "PLAYER_REGEN_ENABLED" then
        MatchFlyoutButtons()
    end
end
