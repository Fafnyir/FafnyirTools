local _, ns = ...

local feature = {
    key = "ActionBarSkin",
    page = "Button Skin",
    searchTerms = {
        "action bar skin", "button skin", "fafnyir", "mask", "masque",
        "normal", "highlight", "checked", "pushed", "disabled",
    },
}
ns:RegisterFeature(feature.key, feature)

local MEDIA = "Interface\\AddOns\\FafnyirTools\\Media\\FafnyirSkin\\"
local skinned = setmetatable({}, { __mode = "k" })
local retryTicker
local hooksInstalled = false

local function DB()
    return ns:GetDatabase().actionBarSkin
end

local function ActionBarModule()
    local modules = EllesmereUI and EllesmereUI._ModuleNS
    return modules and modules.EllesmereUIActionBars
end

local function PromptReload()
    if EllesmereUI and EllesmereUI.ShowConfirmPopup then
        EllesmereUI:ShowConfirmPopup({
            title = "Reload Required",
            message = "Changing the Fafnyir action bar skin requires a UI reload to fully apply or restore button artwork.",
            confirmText = "Reload Now",
            cancelText = "Later",
            onConfirm = ReloadUI,
        })
    else
        ns:Print("Reload the UI to fully apply or restore the action bar skin.")
    end
end

local function SetStateTexture(button, setter, path)
    if type(button[setter]) ~= "function" then return end
    local getterName = setter:gsub("^Set", "Get")
    local getter = button[getterName]
    local current = getter and getter(button)
    if current and current.GetTexture and current:GetTexture() == path then return end
    button[setter](button, path)
    local texture = getter and getter(button)
    if texture and texture.SetAllPoints then
        texture:ClearAllPoints()
        texture:SetAllPoints(button)
    end
end

local function ApplyLiveArt(button)
    local icon = button.icon or button.Icon
    if icon and icon.SetTexCoord then
        icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    end
    SetStateTexture(button, "SetHighlightTexture", MEDIA .. "Highlight")
    SetStateTexture(button, "SetPushedTexture", MEDIA .. "Pushed")
    SetStateTexture(button, "SetCheckedTexture", MEDIA .. "Checked")
    SetStateTexture(button, "SetDisabledTexture", MEDIA .. "Disabled")

    -- The Fafnyir Normal/Edge artwork is the button frame. Hide EllesmereUI's
    -- own solid or textured border so the two complete frames do not stack.
    local pp = EllesmereUI and EllesmereUI.PP
    if pp and pp.HideBorder then pp.HideBorder(button) end
    local bd = EllesmereUI and EllesmereUI._bdBorderData
    if bd and bd[button] then bd[button]:Hide() end

    -- Masque's Border layer is conditional (for example, an equipped item),
    -- not a second always-on copy of the Normal frame.
    local stateBorder = button.Border
    if stateBorder and stateBorder.SetTexture then
        stateBorder:SetTexture(MEDIA .. "Border")
        stateBorder:ClearAllPoints()
        stateBorder:SetAllPoints(button)
    end

    local cooldown = button.cooldown or button.Cooldown
    if cooldown and not InCombatLockdown() then
        cooldown:ClearAllPoints()
        cooldown:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)
        cooldown:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
    end
end

local function SkinButton(button)
    if not button or InCombatLockdown() then return end
    if skinned[button] then
        ApplyLiveArt(button)
        return
    end

    local icon = button.icon or button.Icon
    if not (icon and icon.AddMaskTexture) then return end

    local backdrop = button:CreateTexture(nil, "BACKGROUND", nil, -7)
    backdrop:SetAllPoints(button)
    backdrop:SetTexture(MEDIA .. "Backdrop")

    local mask = button:CreateMaskTexture()
    mask:SetAllPoints(button)
    mask:SetTexture(MEDIA .. "Mask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    icon:AddMaskTexture(mask)

    local normal = button:CreateTexture(nil, "ARTWORK", nil, 6)
    normal:SetAllPoints(button)
    normal:SetTexture(MEDIA .. "Normal")

    skinned[button] = {
        backdrop = backdrop,
        mask = mask,
        normal = normal,
    }
    ApplyLiveArt(button)
end

function feature:Refresh()
    if not DB().enabled or InCombatLockdown() then return false end
    local module = ActionBarModule()
    if not (module and module.barButtons) then return false end

    for _, buttons in pairs(module.barButtons) do
        for _, button in ipairs(buttons) do
            SkinButton(button)
        end
    end
    return true
end

function feature:InstallHooks()
    if hooksInstalled then return end
    local module = ActionBarModule()
    local eab = module and module.EAB
    if not eab then return end
    hooksInstalled = true

    if type(eab.ApplyBorders) == "function" then
        hooksecurefunc(eab, "ApplyBorders", function()
            if DB().enabled and not InCombatLockdown() then feature:Refresh() end
        end)
    end
    if type(eab.ApplyBordersForBar) == "function" then
        hooksecurefunc(eab, "ApplyBordersForBar", function()
            if DB().enabled and not InCombatLockdown() then feature:Refresh() end
        end)
    end
    for _, method in ipairs({ "ApplyPushedTextures", "ApplyHighlightTextures", "ApplyCheckedTextures" }) do
        if type(eab[method]) == "function" then
            hooksecurefunc(eab, method, function()
                if DB().enabled and not InCombatLockdown() then feature:Refresh() end
            end)
        end
    end
end

function feature:Initialize()
    if not DB().enabled then return end
    local attempts = 0
    retryTicker = C_Timer.NewTicker(0.5, function(ticker)
        attempts = attempts + 1
        feature:InstallHooks()
        if feature:Refresh() or attempts >= 20 then
            ticker:Cancel()
            retryTicker = nil
        end
    end)
end

function feature:HandleEvent(event)
    if event == "PLAYER_REGEN_ENABLED" and DB().enabled then
        self:InstallHooks()
        self:Refresh()
    end
end

function feature:Reset()
    DB().enabled = ns.defaults.actionBarSkin.enabled
    PromptReload()
end

function feature:BuildOptions(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y, h = yOffset
    parent._showRowDivider = true

    _, h = W:SectionHeader(parent, "FAFNYIR BUTTON SKIN", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type="toggle", text="Skin EllesmereUI Action Bars",
          getValue=function() return DB().enabled end,
          setValue=function(value)
              if DB().enabled == value then return end
              DB().enabled = value
              if value then feature:Initialize() end
              PromptReload()
          end },
        { type="label", text="Built in; Masque is not required." })
    y = y - h

    _, h = W:DualRow(parent, y,
        { type="label", text="Applies the Fafnyir backdrop, mask, border, and button-state artwork." },
        { type="button", text="Reset Button Skin", buttonText="Reset", onClick=function()
            feature:Reset()
            if EllesmereUI.RefreshPage then EllesmereUI:RefreshPage(true) end
        end })
    y = y - h

    return math.abs(y)
end
