local _, ns = ...

local feature = {
    key = "AuraSkins",
    page = "Aura Skins",
    searchTerms = {
        "aura skins", "buffs", "debuffs", "player auras", "buff frame",
        "debuff frame", "target auras", "target buffs", "target debuffs", "icon zoom", "aura border",
    },
}
ns:RegisterFeature(feature.key, feature)

local GetFFD = EllesmereUI and EllesmereUI._GetFFD
local ICON_ZOOM = 0.055
local BLIZZARD_AURA_ICON_SIZE = 30
local FAFNYIR_MEDIA = "Interface\\AddOns\\FafnyirTools\\Media\\FafnyirSkin\\"
local skinGen = 1
local lastCfg = {}
local durationFormat
local auraDirty = true
local refreshPending = false
local appliedBuffScale, appliedDebuffScale
local hooksInstalled = false
local eventFrame

local function PromptReload()
    if EllesmereUI and EllesmereUI.ShowConfirmPopup then
        EllesmereUI:ShowConfirmPopup({
            title = "Reload Required",
            message = "Changing Aura Skins requires a UI reload to fully apply or restore Blizzard aura styling.",
            confirmText = "Reload Now",
            cancelText = "Later",
            onConfirm = function()
                ReloadUI()
            end,
        })
        return
    end

    StaticPopupDialogs["FAFNYIRTOOLS_AURASKINS_RELOAD"] = StaticPopupDialogs["FAFNYIRTOOLS_AURASKINS_RELOAD"] or {
        text = "Changing Aura Skins requires a UI reload to fully apply or restore Blizzard aura styling.",
        button1 = "Reload Now",
        button2 = "Later",
        OnAccept = function()
            ReloadUI()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
    StaticPopup_Show("FAFNYIRTOOLS_AURASKINS_RELOAD")
end

local function DB()
    return ns:GetDatabase().auraSkins
end

local function UnitFramesLoaded()
    return C_AddOns and C_AddOns.IsAddOnLoaded
        and C_AddOns.IsAddOnLoaded("EllesmereUIUnitFrames")
end

function feature:IsAvailable()
    return not UnitFramesLoaded()
end

local function NoteConfig(cfg)
    local font = (EllesmereUI.GetFontPath and EllesmereUI.GetFontPath("unitFrames")) or ""
    local outline = (EllesmereUI.GetFontOutlineFlag and EllesmereUI.GetFontOutlineFlag("unitFrames")) or ""
    if lastCfg.borderSize == cfg.borderSize
        and lastCfg.borderBehind == cfg.borderBehind
        and lastCfg.noBorderDebuffs == cfg.noBorderDebuffs
        and lastCfg.showText == cfg.showText
        and lastCfg.textSize == cfg.textSize
        and lastCfg.borderR == cfg.borderR
        and lastCfg.borderG == cfg.borderG
        and lastCfg.borderB == cfg.borderB
        and lastCfg.borderA == cfg.borderA
        and lastCfg.borderTexture == cfg.borderTexture
        and lastCfg.offX == cfg.borderTextureOffset
        and lastCfg.offY == cfg.borderTextureOffsetY
        and lastCfg.shiftX == cfg.borderTextureShiftX
        and lastCfg.shiftY == cfg.borderTextureShiftY
        and lastCfg.buffZoom == cfg.buffIconZoom
        and lastCfg.debuffZoom == cfg.debuffIconZoom
        and lastCfg.durFmt == cfg.durationFormat
        and lastCfg.font == font
        and lastCfg.outline == outline
        and lastCfg.targetAuras == cfg.targetAuras
        and lastCfg.fafnyirSkin == cfg.fafnyirSkin then
        return
    end

    lastCfg.borderSize = cfg.borderSize
    lastCfg.borderBehind = cfg.borderBehind
    lastCfg.noBorderDebuffs = cfg.noBorderDebuffs
    lastCfg.showText = cfg.showText
    lastCfg.textSize = cfg.textSize
    lastCfg.borderR, lastCfg.borderG = cfg.borderR, cfg.borderG
    lastCfg.borderB, lastCfg.borderA = cfg.borderB, cfg.borderA
    lastCfg.borderTexture = cfg.borderTexture
    lastCfg.offX, lastCfg.offY = cfg.borderTextureOffset, cfg.borderTextureOffsetY
    lastCfg.shiftX, lastCfg.shiftY = cfg.borderTextureShiftX, cfg.borderTextureShiftY
    lastCfg.buffZoom, lastCfg.debuffZoom = cfg.buffIconZoom, cfg.debuffIconZoom
    lastCfg.durFmt = cfg.durationFormat
    lastCfg.font, lastCfg.outline = font, outline
    lastCfg.targetAuras = cfg.targetAuras
    lastCfg.fafnyirSkin = cfg.fafnyirSkin
    durationFormat = (cfg.durationFormat and cfg.durationFormat ~= "blizzard") and cfg.durationFormat or nil
    skinGen = skinGen + 1
end

local function ApplyFafnyirArt(btn, ffd, iconFrame, iconTex, enabled)
    if not iconTex then return end
    local anchor = iconFrame or btn

    local art = ffd._fafnyirArt
    if not art then
        art = {}

        -- Aura buttons can be much smaller than the skin's 36px reference size
        -- (target auras also switch between small and large). A BackdropTemplate
        -- edge collapses unevenly at those sizes, while Normal.tga already holds
        -- the complete frame. Use Backdrop as a flat underlay only.
        art.backdrop = btn:CreateTexture(nil, "BACKGROUND", nil, -7)
        art.backdrop:SetTexture(FAFNYIR_MEDIA .. "Backdrop")

        art.mask = btn:CreateMaskTexture()
        art.mask:SetTexture(FAFNYIR_MEDIA .. "Mask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        iconTex:AddMaskTexture(art.mask)

        art.normal = btn:CreateTexture(nil, "ARTWORK", nil, 6)
        art.normal:SetTexture(FAFNYIR_MEDIA .. "Normal")

        if btn.SetHighlightTexture then
            btn:SetHighlightTexture(FAFNYIR_MEDIA .. "Highlight")
            art.highlight = btn:GetHighlightTexture()
        end

        ffd._fafnyirArt = art
    end

    art.backdrop:ClearAllPoints()
    art.backdrop:SetAllPoints(anchor)
    art.mask:ClearAllPoints()
    art.mask:SetAllPoints(anchor)
    art.normal:ClearAllPoints()
    art.normal:SetAllPoints(anchor)
    if art.highlight then
        art.highlight:ClearAllPoints()
        art.highlight:SetAllPoints(anchor)
    end

    art.backdrop:SetShown(enabled)
    art.mask:SetShown(enabled)
    art.normal:SetShown(enabled)
    if art.highlight then art.highlight:SetShown(enabled) end
end

local function FormatDuration(timeLeft, style)
    if timeLeft >= 86400 then
        return string.format("%dd", math.floor(timeLeft / 86400 + 0.5))
    end
    if style == "colon" then
        if timeLeft >= 3600 then
            return string.format("%d:%02d", math.floor(timeLeft / 3600), math.floor((timeLeft % 3600) / 60))
        elseif timeLeft >= 60 then
            return string.format("%d:%02d", math.floor(timeLeft / 60), math.floor(timeLeft % 60))
        end
        return string.format("%d", math.floor(timeLeft + 0.5))
    end
    if timeLeft >= 3600 then return string.format("%dh", math.floor(timeLeft / 3600 + 0.5)) end
    if style == "seconds" then return string.format("%d", math.floor(timeLeft + 0.5)) end
    if timeLeft >= 60 then return string.format("%dm", math.floor(timeLeft / 60 + 0.5)) end
    return string.format("%d", math.floor(timeLeft + 0.5))
end

local function SkinButton(btn, isDebuff, cfg, useButtonBounds)
    if not btn or btn.isAuraAnchor or not GetFFD then return end
    local ffd = GetFFD(btn)
    if not ffd then return end
    if ffd._fafAuraSkinned == skinGen and ffd._fafAuraDebuff == isDebuff then return end

    local iconFrame = btn.Icon
    local iconTex
    if iconFrame then
        iconTex = iconFrame.Texture or iconFrame.texture
        if not iconTex and iconFrame.GetRegions then
            for i = 1, iconFrame:GetNumRegions() do
                local r = select(i, iconFrame:GetRegions())
                if r and r.IsObjectType and r:IsObjectType("Texture") and r.SetTexCoord then
                    iconTex = r
                    break
                end
            end
        end
        if not iconTex and iconFrame.SetTexCoord then iconTex = iconFrame end
    end

    if iconTex and iconTex.SetTexCoord then
        local z = cfg.fafnyirSkin and 0.07 or (isDebuff and cfg.debuffIconZoom or cfg.buffIconZoom)
        z = z or ICON_ZOOM
        iconTex:SetTexCoord(z, 1-z, z, 1-z)
    end

    ApplyFafnyirArt(btn, ffd, iconFrame, iconTex, cfg.fafnyirSkin ~= false)

    if btn.StealableBorder and cfg.fafnyirSkin ~= false then
        btn.StealableBorder:SetAlpha(0)
    end

    if btn.DebuffBorder then
        btn.DebuffBorder:SetAlpha((cfg.fafnyirSkin ~= false) and 0
            or ((isDebuff and cfg.noBorderDebuffs) and 1 or 0))
    end

    local durFS = btn.Duration
    if durFS and not durFS.SetFont and durFS.GetRegions then
        for i = 1, durFS:GetNumRegions() do
            local r = select(i, durFS:GetRegions())
            if r and r.SetFont then durFS = r; break end
        end
    end
    if durFS and durFS.SetFont and not ffd._fafAuraDurationHooked and durationFormat
        and type(btn.UpdateDuration) == "function" then
        ffd._fafAuraDurationHooked = true
        local fs = durFS
        hooksecurefunc(btn, "UpdateDuration", function(_, timeLeft)
            if not durationFormat or type(timeLeft) ~= "number" then return end
            if issecretvalue and issecretvalue(timeLeft) then return end
            if timeLeft > 0 then fs:SetText(FormatDuration(timeLeft, durationFormat)) end
        end)
    end

    if durFS and durFS.SetFont then
        if cfg.showText then
            local fontPath = EllesmereUI.GetFontPath and EllesmereUI.GetFontPath("unitFrames") or STANDARD_TEXT_FONT
            local outline = EllesmereUI.GetFontOutlineFlag and EllesmereUI.GetFontOutlineFlag("unitFrames") or "OUTLINE, SLUG"
            if EllesmereUI.PrimeFontShadow then EllesmereUI.PrimeFontShadow(durFS, outline == "") end
            durFS:SetFont(fontPath, cfg.textSize or 11, outline)
            durFS:SetTextColor(1,1,1,1)
        else
            durFS:SetTextColor(0,0,0,0)
        end
    end

    local countFS = btn.Count
    if countFS and not countFS.SetFont and countFS.GetRegions then
        for i = 1, countFS:GetNumRegions() do
            local r = select(i, countFS:GetRegions())
            if r and r.SetFont then countFS = r; break end
        end
    end
    if countFS and countFS.SetFont then
        local fontPath = EllesmereUI.GetFontPath and EllesmereUI.GetFontPath("unitFrames") or STANDARD_TEXT_FONT
        EllesmereUI.ApplyIconTextFont(countFS, fontPath, cfg.textSize or 11, "unitFrames")
    end

    local border = ffd._fafAuraBorder
    if not border then
        border = CreateFrame("Frame", nil, btn)
        border:EnableMouse(false)
        ffd._fafAuraBorder = border
    end
    if cfg.fafnyirSkin ~= false then
        border:Hide()
        ffd._fafAuraSkinned = skinGen
        ffd._fafAuraDebuff = isDebuff
        return
    end
    border:Show()
    border:SetFrameLevel(cfg.borderBehind and math.max(0, btn:GetFrameLevel()-1) or (btn:GetFrameLevel()+10))
    border:ClearAllPoints()
    if useButtonBounds then
        border:SetAllPoints(btn)
    else
        border:SetPoint("CENTER", iconFrame or btn, "CENTER", 0, 0)
        border:SetSize(BLIZZARD_AURA_ICON_SIZE, BLIZZARD_AURA_ICON_SIZE)
    end

    local bs = cfg.borderSize or 1
    local skipBorder = isDebuff and cfg.noBorderDebuffs
    if EllesmereUI.ApplySecretSafeBorderStyle then
        EllesmereUI.ApplySecretSafeBorderStyle(border, ffd,
            (bs > 0 and not skipBorder) and bs or 0,
            cfg.borderR or 0, cfg.borderG or 0, cfg.borderB or 0, cfg.borderA or 1,
            cfg.borderTexture or "solid",
            cfg.borderTextureOffset, cfg.borderTextureOffsetY,
            cfg.borderTextureShiftX, cfg.borderTextureShiftY,
            "unitframes", bs)
    elseif EllesmereUI.ApplyBorderStyle then
        EllesmereUI.ApplyBorderStyle(border,
            (bs > 0 and not skipBorder) and bs or 0,
            cfg.borderR or 0, cfg.borderG or 0, cfg.borderB or 0, cfg.borderA or 1,
            cfg.borderTexture or "solid",
            cfg.borderTextureOffset, cfg.borderTextureOffsetY,
            cfg.borderTextureShiftX, cfg.borderTextureShiftY,
            "unitframes", bs)
    end

    ffd._fafAuraSkinned = skinGen
    ffd._fafAuraDebuff = isDebuff
end

local function SkinAll(frame, isDebuff, cfg)
    if not frame or not frame.auraFrames then return end
    for _, btn in pairs(frame.auraFrames) do
        if btn and btn.Icon and not btn.isAuraAnchor then SkinButton(btn, isDebuff, cfg) end
    end
end

local function SkinTargetFrameAuras(cfg)
    if cfg.targetAuras == false then return end
    if not TargetFrame then return end

    local skinnedAny = false
    local auraContainer
    if type(TargetFrame.GetAuraContainer) == "function" then
        local ok, container = pcall(TargetFrame.GetAuraContainer, TargetFrame)
        if ok then auraContainer = container end
    end
    auraContainer = auraContainer or TargetFrame.Auras or TargetFrame
    local pools = auraContainer and auraContainer.auraPools

    -- Public fallback for the secure 12.1 TargetFrame AuraContainer. Its pool
    -- and group registries can live in the private object partition and be
    -- invisible to addon code, but assigned AuraButtons remain ordinary direct
    -- children. Their template-specific border fields identify the group.
    if auraContainer and type(auraContainer.GetChildren) == "function" then
        local children = { auraContainer:GetChildren() }
        for _, btn in ipairs(children) do
            if btn and btn.Icon then
                if btn.StealableBorder then
                    SkinButton(btn, false, cfg, true)
                    skinnedAny = true
                elseif btn.DispelBorder then
                    SkinButton(btn, true, cfg, true)
                    skinnedAny = true
                end
            end
        end
    end

    -- The live aura groups are the authoritative 12.1 assignment lists. Pool
    -- enumeration can miss buttons when Blizzard swaps between public and
    -- forbidden templates, whereas GetFramesByIndex returns the frames actually
    -- assigned to Buffs and Debuffs right now.
    local function SkinAuraGroup(group, isDebuff)
        if not (group and type(group.GetFramesByIndex) == "function") then return end
        local ok, frames = pcall(group.GetFramesByIndex, group)
        if not ok or type(frames) ~= "table" then return end
        for _, btn in ipairs(frames) do
            if btn then
                SkinButton(btn, isDebuff, cfg, true)
                skinnedAny = true
            end
        end
    end
    SkinAuraGroup(auraContainer and auraContainer.buffAuraGroup, false)
    SkinAuraGroup(auraContainer and auraContainer.debuffAuraGroup, true)

    -- Modern Blizzard TargetFrame: aura buttons are allocated from frame pools,
    -- not stable TargetFrameBuff1/TargetFrameDebuff1 globals. Midnight 12.1
    -- renamed the templates from Target*FrameTemplate to
    -- TargetFrame*ButtonTemplate, so probe both generations (and the forbidden
    -- variants used while unit data is restricted).
    if pools and pools.GetPool then
        local function SkinPool(templateNames, isDebuff)
            for _, templateName in ipairs(templateNames) do
                local pool = pools:GetPool(templateName)
                if pool and pool.EnumerateActive then
                    for btn in pool:EnumerateActive() do
                        if btn then
                            SkinButton(btn, isDebuff, cfg, true)
                            skinnedAny = true
                        end
                    end
                end
            end
        end
        SkinPool({
            "TargetFrameBuffButtonTemplate",
            "ForbiddenTargetFrameBuffButtonTemplate",
            "TargetBuffFrameTemplate",
        }, false)
        SkinPool({
            "TargetFrameDebuffButtonTemplate",
            "ForbiddenTargetFrameDebuffButtonTemplate",
            "TargetDebuffFrameTemplate",
        }, true)
    end

    -- Legacy fallback for clients/layouts that still expose named target aura buttons.
    if not skinnedAny then
        local maxBuffs = MAX_TARGET_BUFFS or 40
        local maxDebuffs = MAX_TARGET_DEBUFFS or 40

        for i = 1, maxBuffs do
            local btn = _G["TargetFrameBuff" .. i]
            if btn then
                SkinButton(btn, false, cfg, true)
            elseif i > 8 then
                break
            end
        end

        for i = 1, maxDebuffs do
            local btn = _G["TargetFrameDebuff" .. i]
            if btn then
                SkinButton(btn, true, cfg, true)
            elseif i > 8 then
                break
            end
        end
    end
end

local function ApplyExpandButton()
    local cfg = DB()
    local button = BuffFrame and BuffFrame.CollapseAndExpandButton
    if not button then return end
    if cfg.showExpandButton == false then button:Hide() else button:Show() end
end

function feature:ApplyScale()
    if not self:IsAvailable() then return end
    local cfg = DB()
    if not cfg.enabled then return end
    local scale = (cfg.iconSize or 32) / 32
    if BuffFrame and BuffFrame.AuraContainer and appliedBuffScale ~= scale then
        BuffFrame.AuraContainer:SetScale(scale); appliedBuffScale = scale
    end
    if DebuffFrame and DebuffFrame.AuraContainer and appliedDebuffScale ~= scale then
        DebuffFrame.AuraContainer:SetScale(scale); appliedDebuffScale = scale
    end
    ApplyExpandButton()
end

function feature:Refresh()
    if not self:IsAvailable() then return end
    local cfg = DB()
    if not cfg.enabled then return end
    NoteConfig(cfg)
    auraDirty = false
    SkinAll(BuffFrame, false, cfg)
    SkinAll(DebuffFrame, true, cfg)
    SkinTargetFrameAuras(cfg)
    self:ApplyScale()
end

local function PendingRefresh()
    refreshPending = false
    if auraDirty then feature:Refresh() end
end

local function RequestRefresh()
    if refreshPending or not auraDirty then return end
    refreshPending = true
    C_Timer.After(0, PendingRefresh)
end

function feature:InstallHooks()
    if hooksInstalled or not self:IsAvailable() then return end
    hooksInstalled = true
    for _, frame in ipairs({BuffFrame, DebuffFrame}) do
        if frame and frame.AuraContainer and type(frame.AuraContainer.UpdateGridLayout) == "function" then
            hooksecurefunc(frame.AuraContainer, "UpdateGridLayout", RequestRefresh)
        end
    end
    local b = BuffFrame and BuffFrame.CollapseAndExpandButton
    if b and type(BuffFrame.RefreshConsolidationFrameVisibility) == "function" then
        hooksecurefunc(BuffFrame, "RefreshConsolidationFrameVisibility", ApplyExpandButton)
    end

    local function TargetAuraRefreshHook()
        if not feature:IsAvailable() or not DB().enabled or DB().targetAuras == false then return end
        auraDirty = true
        RequestRefresh()
    end

    if TargetFrame then
        if type(TargetFrame.UpdateAuras) == "function" then
            hooksecurefunc(TargetFrame, "UpdateAuras", TargetAuraRefreshHook)
        end
        if type(TargetFrame.UpdateAuraFrames) == "function" then
            hooksecurefunc(TargetFrame, "UpdateAuraFrames", TargetAuraRefreshHook)
        end
    end

    if type(TargetFrame_UpdateAuras) == "function" then
        hooksecurefunc("TargetFrame_UpdateAuras", TargetAuraRefreshHook)
    end

    if TargetFrame and TargetFrame.HookScript then
        TargetFrame:HookScript("OnShow", function()
            if not feature:IsAvailable() or not DB().enabled or DB().targetAuras == false then return end
            auraDirty = true
            RequestRefresh()
        end)
    end
end

function feature:Initialize()
    if not self:IsAvailable() then return end
    self:InstallHooks()
    if not eventFrame then
        eventFrame = CreateFrame("Frame")
        eventFrame:RegisterEvent("UNIT_AURA")
        eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
        eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
        eventFrame:SetScript("OnEvent", function(_, event, unit)
            if event == "UNIT_AURA" then
                if unit ~= "player" and unit ~= "target" then return end
                if unit == "target" and DB().targetAuras == false then return end
            end
            auraDirty = true
            RequestRefresh()
        end)
    end
    auraDirty = true
    self:Refresh()
end

function feature:Reset()
    local d = DB()
    local defaults = ns.defaults.auraSkins
    for k,v in pairs(defaults) do d[k] = v end
    skinGen = skinGen + 1
    auraDirty = true
    self:Refresh()
end

local function Disabled()
    return not feature:IsAvailable()
end

local function PAOff()
    return Disabled() or not DB().enabled
end

local function SetValue(key, value)
    DB()[key] = value
    skinGen = skinGen + 1
    auraDirty = true
    feature:Refresh()
end

local function AttachColorSwatch(region)
    if not EllesmereUI.BuildColorSwatch then return end
    local swatch, refresh = EllesmereUI.BuildColorSwatch(
        region, region:GetFrameLevel()+5,
        function()
            local d=DB(); return d.borderR or 0,d.borderG or 0,d.borderB or 0,d.borderA or 1
        end,
        function(r,g,b,a)
            local d=DB(); d.borderR=r; d.borderG=g; d.borderB=b; d.borderA=a or 1
            skinGen=skinGen+1; auraDirty=true; feature:Refresh()
        end,
        true, 20)
    swatch:SetPoint("RIGHT", region._control or region, "LEFT", -8, 0)
    region._lastInline=swatch
    if EllesmereUI.RegisterWidgetRefresh then EllesmereUI.RegisterWidgetRefresh(refresh) end
end

function feature:BuildOptions(parent, yOffset)
    local W=EllesmereUI.Widgets
    local y=yOffset
    local h
    parent._showRowDivider=true

    _,h=W:SectionHeader(parent,"AURA SKINS",y); y=y-h

    if Disabled() then
        _,h=W:DualRow(parent,y,
            {type="label",text="Aura Skins unavailable while EllesmereUI Unit Frames is loaded."},
            {type="label",text="Disable EllesmereUI Unit Frames and /reload to use this feature."})
        y=y-h
        return math.abs(y)
    end

    _,h=W:DualRow(parent,y,
        {type="toggle",text="Enable Styled Buffs & Debuffs",
         getValue=function() return DB().enabled end,
         setValue=function(v)
            local old = DB().enabled
            SetValue("enabled",v)
            if old ~= v then PromptReload() end
         end},
        {type="slider",text="Icon Size",min=16,max=60,step=1,disabled=PAOff,
         getValue=function() return DB().iconSize or 32 end,
         setValue=function(v) SetValue("iconSize",v) end})
    y=y-h

    _,h=W:DualRow(parent,y,
        {type="slider",text="Buff Icon Zoom",min=0,max=0.20,step=0.01,disabled=PAOff,
         getValue=function() return DB().buffIconZoom or ICON_ZOOM end,
         setValue=function(v) SetValue("buffIconZoom",v) end},
        {type="slider",text="Debuff Icon Zoom",min=0,max=0.20,step=0.01,disabled=PAOff,
         getValue=function() return DB().debuffIconZoom or ICON_ZOOM end,
         setValue=function(v) SetValue("debuffIconZoom",v) end})
    y=y-h

    _,h=W:DualRow(parent,y,
        {type="toggle",text="Show Duration Text",disabled=PAOff,
         getValue=function() return DB().showText ~= false end,
         setValue=function(v) SetValue("showText",v) end},
        {type="slider",text="Text Size",min=6,max=24,step=1,disabled=PAOff,
         getValue=function() return DB().textSize or 11 end,
         setValue=function(v) SetValue("textSize",v) end})
    y=y-h

    _,h=W:DualRow(parent,y,
        {type="dropdown",text="Duration Format",disabled=PAOff,
         values={blizzard="Blizzard Default",compact="Standard",colon="Colon",seconds="Seconds"},
         order={"blizzard","compact","colon","seconds"},
         getValue=function() return DB().durationFormat or "blizzard" end,
         setValue=function(v) SetValue("durationFormat",v) end},
        {type="toggle",text="Show Expand Button",disabled=PAOff,
         getValue=function() return DB().showExpandButton ~= false end,
         setValue=function(v) SetValue("showExpandButton",v) end})
    y=y-h

    _,h=W:DualRow(parent,y,
        {type="toggle",text="Skin Target Frame Auras",disabled=PAOff,
         getValue=function() return DB().targetAuras ~= false end,
         setValue=function(v) SetValue("targetAuras",v) end},
        {type="label",text="Uses the same style for Blizzard target buffs and debuffs."})
    y=y-h

    _,h=W:DualRow(parent,y,
        {type="toggle",text="Use Fafnyir Artwork",disabled=PAOff,
         getValue=function() return DB().fafnyirSkin ~= false end,
         setValue=function(v) SetValue("fafnyirSkin",v) end},
        {type="label",text="Built in; Masque is not required."})
    y=y-h

    local texValues,texOrder=EllesmereUI.GetBorderTextureDropdown()
    local borderRow
    borderRow,h=W:DualRow(parent,y,
        {type="dropdown",text="Border Style",disabled=PAOff,values=texValues,order=texOrder,
         getValue=function() return DB().borderTexture or "solid" end,
         setValue=function(v)
            local color,behind=EllesmereUI.GetBorderStyleSelectDefaults(v)
            local d=DB(); d.borderTexture=v; d.borderBehind=behind
            d.borderR=color.r; d.borderG=color.g; d.borderB=color.b; d.borderA=1
            d.borderTextureOffset=nil; d.borderTextureOffsetY=nil; d.borderTextureShiftX=nil; d.borderTextureShiftY=nil
            local sz=EllesmereUI.GetBorderDefaultSize("unitframes",v); if sz then d.borderSize=sz end
            skinGen=skinGen+1; auraDirty=true; feature:Refresh()
         end},
        {type="slider",text="Border Size",min=0,max=4,step=1,disabled=PAOff,
         getValue=function() return DB().borderSize or 1 end,
         setValue=function(v) SetValue("borderSize",v) end})
    y=y-h
    if borderRow and borderRow._rightRegion then AttachColorSwatch(borderRow._rightRegion) end

    _,h=W:DualRow(parent,y,
        {type="toggle",text="Use Blizzard Debuff Border",disabled=PAOff,
         getValue=function() return DB().noBorderDebuffs == true end,
         setValue=function(v) SetValue("noBorderDebuffs",v) end},
        {type="button",text="Reset Aura Skin Settings",buttonText="Reset",onClick=function()
            feature:Reset(); if EllesmereUI.RefreshPage then EllesmereUI:RefreshPage(true) end
         end})
    y=y-h

    return math.abs(y)
end
